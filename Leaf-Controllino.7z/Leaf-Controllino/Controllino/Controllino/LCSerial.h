/*
 * LCSerial.h
 *
 *  Created on: 12.06.2019
 *      Author: Boris.Kajganic
 */

#ifndef LCSERIAL_H_
#define LCSERIAL_H_

/*
class LCSerial
{
public:
  LCSerial();
  virtual ~LCSerial();
};
*/

#endif /* LCSERIAL_H_ */
