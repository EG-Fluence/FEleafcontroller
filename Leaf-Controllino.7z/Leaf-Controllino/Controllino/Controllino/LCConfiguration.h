/*
 * LeafController_Configuration.h
 *
 *  Created on: 12.06.2019
 *      Author: Boris.Kajganic
 */

#ifndef LCCONFIGURATION_H_
#define LCCONFIGURATION_H_

/*
class LCConfiguration
{
public:
  LCConfiguration();
  virtual ~LCConfiguration();
};
*/

#endif /* LCCONFIGURATION_H_ */
