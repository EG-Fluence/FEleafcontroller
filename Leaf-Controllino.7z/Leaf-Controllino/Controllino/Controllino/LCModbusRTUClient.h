/*
 * LeafController_ModbusRTUClient.h
 *
 *  Created on: 12.06.2019
 *      Author: Boris.Kajganic
 */

#ifndef LCMODBUSRTUCLIENT_H_
#define LCMODBUSRTUCLIENT_H_

/*
class LCModbusRTUClient
{
public:
  LCModbusRTUClient();
  virtual ~LCModbusRTUClient();
};
*/

#endif /* LCMODBUSRTUCLIENT_H_ */
