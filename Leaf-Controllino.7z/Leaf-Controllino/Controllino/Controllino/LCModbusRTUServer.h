/*
 * LeafController_ModbusRTUServer.h
 *
 *  Created on: 19.08.2019
 *      Author: Boris.Kajganic
 */

#ifndef LCMODBUSRTUSERVER_H_
#define LCMODBUSRTUSERVER_H_

/*
class LCModbusRTUServer
{
public:
  LCModbusRTUServer();
  virtual ~LCModbusRTUServer();
};
*/

#endif /* LCMODBUSRTUSERVER_H_ */
