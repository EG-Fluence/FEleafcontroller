/*
 * LeafController_ModbusTCPServer.h
 *
 *  Created on: 12.06.2019
 *      Author: Boris.Kajganic
 */

#ifndef LCMODBUSTCPSERVER_H_
#define LCMODBUSTCPSERVER_H_

/*
class LCModbusTCPServer
{
public:
  LCModbusTCPServer();
  virtual ~LCModbusTCPServer();
};
*/

#endif /* LCMODBUSTCPSERVER_H_ */
