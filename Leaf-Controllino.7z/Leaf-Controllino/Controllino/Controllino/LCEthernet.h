/*
 * LCEthernet.h
 *
 *  Created on: 12.06.2019
 *      Author: Boris.Kajganic
 */

#ifndef LCETHERNET_H_
#define LCETHERNET_H_

/*
class LCEthernet
{
public:
  LCEthernet();
  virtual ~LCEthernet();
};
*/

#endif /* LCETHERNET_H_ */
