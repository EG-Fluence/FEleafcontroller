/*
 * LeafController_Configuration.cpp
 *
 *  Created on: 12.06.2019
 *      Author: Boris.Kajganic
 */

#include "LCConfiguration.h"

/*
LCConfiguration::LCConfiguration()
{
  // TODO Auto-generated constructor stub

}

LCConfiguration::~LCConfiguration()
{
  // TODO Auto-generated destructor stub
}

*/
