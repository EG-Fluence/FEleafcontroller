
CFG_LOCAL = False
DEBUG = True

MaximumWriteAttempts = 3
MaximumReadAttempts = 3

ReadMessages_counter = 0
ReadMessages_error_counter = 0

WriteMessages_counter = 0
WriteMessages_error_counter = 0
