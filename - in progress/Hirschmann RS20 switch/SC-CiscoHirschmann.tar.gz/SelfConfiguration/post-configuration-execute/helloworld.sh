#!/bin/sh

echo Hello World  $FLUENCE_IP $FLUENCE_HOSTNAME

