#!/bin/bash

# we call the script here since it's already done by Boris
/usr/local/bin/fluence_iptables.sh

